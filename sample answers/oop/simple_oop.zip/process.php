<?php 

class Math {

	function add($first_number, $second_number)
	{
		return $first_number + $second_number;
	}

	function minus($first_number, $second_number)
	{
		return $first_number - $second_number;
	}

	function multiply($first_number, $second_number)
	{
		return $first_number * $second_number;
	}

	function divide($first_number, $second_number)
	{
		return $first_number / $second_number;
	}
}


?>