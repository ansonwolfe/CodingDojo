<?php

include('process.php');

$new_math = new Math();

echo $new_math->add(2, 7);

