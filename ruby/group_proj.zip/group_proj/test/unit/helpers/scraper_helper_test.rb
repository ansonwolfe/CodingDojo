require 'test_helper'

class ScraperHelperTest < ActionView::TestCase
end
