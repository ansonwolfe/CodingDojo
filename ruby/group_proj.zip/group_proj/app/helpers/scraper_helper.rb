module ScraperHelper
end
