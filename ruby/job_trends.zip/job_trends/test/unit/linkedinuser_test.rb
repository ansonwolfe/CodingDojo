require 'test_helper'

class LinkedinuserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
