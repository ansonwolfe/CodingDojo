require 'test_helper'

class ScrapeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
