require 'test_helper'

class LinkedinTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
