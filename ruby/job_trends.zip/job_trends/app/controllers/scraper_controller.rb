class ScraperController < ApplicationController
  def get

		# require 'watir-webdriver'
		# require 'nokogiri'
		# require 'rubygems'

		browser = Watir::Browser.new
		# b.visible = false
		browser.goto 'https://www.linkedin.com/nhome/'
		puts '1'
		browser.text_field(:id =>'session_key-login').set 'gayabhaskar@gmail.com'
		puts '2'
		browser.text_field(:id =>'session_password-login').set 'oscarfelix'
		login = browser.button(:name => 'signin')
		login.exists?
		login.click
		puts '3'

		l = browser.link :text => 'Jobs'
		l.exists?
		l.click
		puts '4'

		p = browser.text_field(:id =>'job-search-box').set 'PHP'
		btn = browser.button(:name => 'jsearch')
		btn.exists?
		btn.click
		puts '5'

		@page_html = Nokogiri::HTML.parse('browser.html')
		# @links = page_html.css("a")
		# @site_scrape = page_html.xpath('.//*[(@id = "results-summary")]//strong').text
		# Linkedin.create(:count => site_scrape) 
		# //*[(@id = "results-summary")]//strong
  end
end
