
class ResultsController < ApplicationController
  def index
  end

  def get
    SearchUrl.crawl
    @dice = Skill.where(:site_id => 1).order('name ASC')
    @craig = Skill.where(:site_id => 2).order('name ASC')
  end

end