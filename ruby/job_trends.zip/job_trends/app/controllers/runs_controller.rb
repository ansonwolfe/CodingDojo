class RunsController < ApplicationController
  def index
  end
end
