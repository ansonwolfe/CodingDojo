class Linkedinuser < ActiveRecord::Base
  attr_accessible :location, :password, :username, :zipcode
end
