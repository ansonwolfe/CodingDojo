class Linkedin < ActiveRecord::Base
  attr_accessible :keyword, :linkedinuser_id, :url
end
