class CreateLinkedins < ActiveRecord::Migration
  def change
    create_table :linkedins do |t|
      t.integer :linkedinuser_id
      t.string :keyword
      t.string :url

      t.timestamps
    end
  end
end
