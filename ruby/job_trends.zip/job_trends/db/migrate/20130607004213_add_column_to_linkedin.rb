class AddColumnToLinkedin < ActiveRecord::Migration
  def change
    add_column :linkedins, :count, :integer
  end
end
