class CreateLinkedinusers < ActiveRecord::Migration
  def change
    create_table :linkedinusers do |t|
      t.string :username
      t.string :password
      t.string :location
      t.integer :zipcode

      t.timestamps
    end
  end
end
