<?php
	session_start();
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login Screen</title>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>

	<div class="span12">
		<div class="header hero-unit">
			<img src="http://s3.amazonaws.com/creattica/designs/images/109846/original/farmdog_fu-jbyvnr.jpg">
		</div>

		<div class="container-fluid">	
			<div class="row">	
				<form action="registration.php" method="post" class="span4 offset1">
					<h3>New User? Register Now</h3>
					<!-- sets up container where error messages are displayed. This is the array which the following php checks error messages against -->
					<?php
						if(isset($_SESSION['error']))
						{
							echo "<div class='alert alert-error'> <ul>" ;
							
							foreach ($_SESSION['error'] as $message) 
							{
								echo "<li>" . $message . "</li>";
							}
							echo "</ul> </div>";
						}	
					?>	
					<!-- highlights required fields (minus birthdate) -->
					<div class="control-group  <?php if (isset($_SESSION['error']['req_fields']))
								{
									echo ' error';
								} ?>">
						<!-- php checks for valid email format, highlight text box -->
						<div class="control-group<?php if (isset($_SESSION['error']['email']))
									{
										echo ' error';
									} ?>">
							<label>Email*</label>
							<input type="text" name = "email" placeholder="email">
						</div>
						<!-- php in class checks if numbers were in fields, highlights text box -->
						<div class="control-group <?php if (isset($_SESSION['error']['numbers']))
									{
										echo ' error';
									} ?>">
							<label>First Name*</label>
							<input type="text" name="first_name" placeholder="First Name" />					
						</div>
						
						<div class="control-group  <?php if (isset($_SESSION['error']['numbers']))
									{
										echo ' error';
									} ?>">
							<label>Last Name*</label>
							<input type="text" name="last_name" placeholder="Last Name" class="control-group error"/>		
						</div>

						<label>Username*</label>
						<input type="text" name="username" placeholder="Username" />	
								<!--  php checks for password error and password match, highlight field if error exists-->
						<div class="control-group <?php if (isset($_SESSION['error']['password']))
								{
									echo ' error';
								} ?>">
							<label>Password*</label>
							<input type="password" name="password" placeholder="Password" />
						</div>
						<div class="control-group <?php if (isset($_SESSION['error']['password_match']))
								{
									echo ' error';
								} ?>">
							<label>Confirm Password*</label>
							<input type="password" name="confirm_password" placeholder="Confirm Password" />
						</div>	
					</div>
					<!-- php in class checks for error message in date, highlight field -->
					<div class="control-group <?php if (isset($_SESSION['error']['date']))
								{
									echo ' error';
								} ?>">
						<label>Birth Date (mm/dd/yyyy)</label>
						<input type="text" name="birth_date" placeholder="Birth Date" />
					</div>
					<br />
					<input type="submit" name="registration" value="Register" class="btn btn-info" />
				</form>
				<form action="registration.php" method="post" class="span4 offset2">
					<h3>Registered? Login Now</h3>
					<label>Username</label>
					<input type="text" name="username" placeholder="username" />
					<br />
					<label>Password</label>
					<input type="text" name="password" placeholder="Password" />
					<br />
					<input type="submit" name="registration" value="Login" class="btn btn-info" />
				</form>
			</div>
		</div>
	</div>	
<?php unset($_SESSION['error']); ?>
	
</body>
</html>