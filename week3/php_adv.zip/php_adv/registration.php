<?php
 	session_start();

 	header("Location:index.php");

// function to check if numeric
	function is_a_word($var)
	{
		$word = str_split($var);
			foreach ($word as $letter) 
			{
				if (is_numeric($letter))
					$_SESSION['error']['numbers'] = "Invalid name!";
			}
	};
	is_a_word($_POST['first_name']);
 	is_a_word($_POST['last_name']);

// checks if fields are null
 	function null($var)
 	{
 		if (strlen($var)< 1) 
 		{
	 	$_SESSION['error']['req_fields'] = "Field is required.";
 		}
 	}
 	null($_POST['first_name']);
	null($_POST['last_name']);
	null($_POST['username']);
	null($_POST['confirm_password']);

//check if email is valid
		if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL))
		{
			$_SESSION['error']['email'] = "Invalid email entered.";
		}	

// check if password has more than 6 characters
	if (strlen($_POST['password']) < 6)
		{
			$_SESSION['error']['password'] = "Password needs to be longer than 6 characters.";
		}	
	if (($_POST['password']) != ($_POST['confirm_password']))
		{
			$_SESSION['error']['password_match'] = "Passwords do not match.";
		}
// grabs birthdate entered, breaks into month, day, year and checks for format.
	$date = $_POST['birth_date'];
	list($m, $d, $y) = explode("/", $date);
		if (FALSE ===(checkdate($m, $d, $y)))
		{
			$_SESSION['error']['date'] = "Date needs to be in mm/dd/yyyy format.";
		}



 	// var_dump($_SESSION);
?>