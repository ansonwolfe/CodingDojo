<?php
	session_start();

	if(isset($_POST['fibonacci'])) {
		fibonacci();
	}

	function fibonacci() {
		$results = array();
		if (is_numeric($_POST['first_number'])) {
			$num1 = $_POST['first_number'];
		}	

		if (is_numeric($_POST['first_number'])) {
		$num2 = $_POST['second_number'];
		}
		// echo $num1 . " , " . $num2;

		for ($i=0; $i < $_POST['series'] ; $i++) { 
			$fib_num = $num1 + $num2; 
			
			$results[] = $fib_num;

			$num1 = $num2;
			$num2 = $fib_num;
		}

		$_SESSION['num1'] = $_POST['first_number'];
		$_SESSION['num2'] = $_POST['second_number'];
		$_SESSION['results'] = $results;
		// var_dump($_SESSION['results']);
	}

	 header ("Location: index.php");