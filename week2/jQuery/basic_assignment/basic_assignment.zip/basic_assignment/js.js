$("#addclass_button").click(function(){
	$("#sample_text").addClass(".highlight");
});
