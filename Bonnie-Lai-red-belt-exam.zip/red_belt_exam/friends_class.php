<?php
	include ("process.php");

// var_dump($_SESSION);

	class Friends {

		var $users;
		var $my_pokes;
		var $process;

		function __construct(){
			$this->process = new Process();
			$this->all_users();
			$this->my_pokes();
		}
		// get all users
		function all_users(){
			$query = "SELECT first_name, last_name, email, id FROM users";
			return $this->users = $this->process->connection->fetch_all($query);	
			//var_dump($friends);
		}
		// get my friends
		function my_pokes(){
			$query = "SELECT COUNT(*) AS count, id, first_name, last_name, email, friend_id FROM users
						LEFT JOIN friends ON friend_id = users.id 
						WHERE user_id = {$_SESSION['user']['id']}
						GROUP BY first_name
						";
			return $this->my_pokes = $this->process->connection->fetch_all($query);			
		}
		// incomplete
		function poking_me(){
			$query = "SELECT COUNT(*) AS count, id, first_name, last_name, email, friend_id FROM users
						LEFT JOIN friends ON friend_id = users.id 
						WHERE user_id = {$_SESSION['user']['id']}
						GROUP BY first_name
						";
			return $this->my_pokes = $this->process->connection->fetch_all($query);			
		}

	}

	// Poke ! Poke ! Poke !
	Class Pokes {

		// var $poked;
		// var $process;

		// function __construct(){
		// 	$this->poked_friends();
		// }	
		// function poked_friends(){

		// 	$query = mysql_query("SELECT to_id, COUNT(*) AS num_pokes FROM friend_finder.pokes 
		// 				WHERE from_id = '{$_SESSION['user']['id']}' GROUP BY to_id");
		// 	return $this->poked_friends = mysql_fetch_array($query, MYSQL_BOTH);	
		// }

		function poke_friend(){

			$query = "INSERT INTO friends (user_id, friend_id)
			VALUES ('{$_SESSION['user']['id']}','{$_POST['friend_id']}')";

			mysql_query($query);	
			header('Location: friends.php');
		}
	}	

	// if poke is invoked, run poke_friend function
		if(isset($_POST['friend_id'])){
		$poke = new Pokes();
		$poke -> poke_friend();	
		}

?>