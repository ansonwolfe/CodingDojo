<?php
	//session_start();
	include "friends_class.php";

	$friends = new Friends();
	$users = $friends->all_users();
	$my_pokes = $friends->my_pokes();
	// echo "<pre>";
	// var_dump($my_pokes);
	// echo "</pre>";
	$pokes = new Pokes();
	// $poked_friends = $pokes->poked_friends();
	// 	echo "<pre>";
	// var_dump($poked_friends);
	// 	echo "</pre>";
?>

<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Friend Finder</title>
	<style type="text/css">
		table {
			border: 1px solid silver;
			margin: 10px;
			border-collapse: collapse;
		}
		table td {
			border: 1px solid silver;
			padding: 5px 15px;

		}
	</style>
</head>
<body>

	<h3>Welcome <?= $_SESSION['user']['first_name']?> !</h3>
	<?= $_SESSION['user']['email']?>

	<form method="post" action="process.php">
		<input type="hidden" name="action" value="logout">
		<input type="submit" value="Log Out">
	</form>


	<h2>Who has poked me?</h2>
	<div id="list_of_friends">
		<table>
			<thead>
				<tr>
					<td>Name</td>
					<td>Pokes</td>
				</tr>
			</thead>
			<tbody>
				<?php 
					foreach ($my_pokes as $my_poke) {
						echo "<tr>
								<td>" . $my_poke['first_name'] . " " . $my_poke['last_name'] . "</td>
								<td>" . $my_poke['count'] . "</td>
						  	</tr>";
					} ?>
			</tbody>
		</table>		
	</div>
	<h2>People you may want to poke</h2>
	<div id="list_of_subscribers">
		<table>
			<thead>
				<tr>
					<td>Name</td>
					<td>Email</td>
					<td>Poke History</td>
					<td>Action</td>
				</tr>
			</thead>
			<tbody>
				<?php
					foreach ($my_pokes as $my_poke) {
						echo "<tr>
								<td>" . $my_poke['first_name'] ."</td> 								
								<td>" . $my_poke['email'] . "</td> 
								<td> Poked ". $my_poke['count'] ." times</td> 
								<td> 
									<form action='friends_class.php' method='post'>
										<input type='hidden' name='friend_id' value=" . $my_poke['id'] . ">
										<input type='submit' value='Poke!'>
									</form>
								</td>										
						  	</tr>";
					}
				?>
			</tbody>	
		</table>
	<div>	
</body>
</html>