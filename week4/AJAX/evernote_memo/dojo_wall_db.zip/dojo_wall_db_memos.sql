CREATE DATABASE  IF NOT EXISTS `dojo_wall_db` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `dojo_wall_db`;
-- MySQL dump 10.13  Distrib 5.5.24, for osx10.5 (i386)
--
-- Host: 127.0.0.1    Database: dojo_wall_db
-- ------------------------------------------------------
-- Server version	5.5.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `memos`
--

DROP TABLE IF EXISTS `memos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `memo` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_memos_users1_idx` (`user_id`),
  CONSTRAINT `fk_memos_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memos`
--

LOCK TABLES `memos` WRITE;
/*!40000 ALTER TABLE `memos` DISABLE KEYS */;
INSERT INTO `memos` VALUES (1,1,'Hello',NULL,NULL),(4,1,'Help! textfield does not like special characters. What can I do to get this fixed? \r\n','2013-05-06 13:09:49',NULL),(8,1,'Packs of killer whales are systematically tracking down and feeding on young gray whales in Monterey Bay.','2013-05-06 13:45:10',NULL),(9,1,'Owners are ready to pour $13.7M into upscale Randy Rooster SF right next to Harvey Milk Plaza. Neighbors are abuzz.\r\n','2013-05-06 13:45:49',NULL),(10,1,'Are you here? Are you here? Are you here? Are you here? Are you here? Are you here? Are you here? Are you here? Are you here? Are you here? Are you here? ','2013-05-06 13:47:59',NULL),(12,1,'Dojo Rules:\r\nBe Present\r\nBe Humble\r\nStrength Through Struggle','2013-05-06 13:50:30',NULL),(13,1,'BLAH BLAH!','2013-05-06 15:12:31',NULL),(15,1,'I\'m Tall! You\'re short! ','2013-05-06 15:24:57',NULL),(16,1,'Do memos post without refresh? ','2013-05-06 15:27:48',NULL),(17,40,'Testing memo under different login name','2013-05-06 15:42:07',NULL),(18,40,'going smooth','2013-05-06 15:42:56',NULL),(19,1,'Muhahhahaha!','2013-05-06 22:05:29',NULL);
/*!40000 ALTER TABLE `memos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-05-07  9:26:02
