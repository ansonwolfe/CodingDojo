require 'test_helper'

class RunsHelperTest < ActionView::TestCase
end
