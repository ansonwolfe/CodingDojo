require 'test_helper'

class ResultsHelperTest < ActionView::TestCase
end
