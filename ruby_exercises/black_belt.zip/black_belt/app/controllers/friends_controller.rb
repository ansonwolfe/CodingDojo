class FriendsController < ApplicationController
  def new
  end

  # changes status to 1 so friend goes to friend approval status
 	 def create
 	 		@friend = Friend.new(params[:friend])
			# @friend = Friend.find(params[:id]).comments.new(params[:comment])

		if @friend.save
			@user = User.find(session[:user_id])
			redirect_to @user
		else
			render action: "new"	
		end	
  	end	

  	def show
  		
  	end	

	# changes status to 2 so becomes friend
	def edit

	end	
	# destroy removes status so friend goes back to list
	def destroy
		@ignore = Friend.where(:user_id => params[:id])
		@ignore.destroy
		redirect_to @user
	end
end
