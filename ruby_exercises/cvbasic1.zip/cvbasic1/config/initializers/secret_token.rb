# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Cvbasic1::Application.config.secret_token = 'b508f44137467f12dab8488fe2bb3c92522318b030f373c04b9a56c6d1590db81c4838d58fc8ce8372d5fe4bbc852b80dedee40b630ace1cba8058effdc1d8b5'
