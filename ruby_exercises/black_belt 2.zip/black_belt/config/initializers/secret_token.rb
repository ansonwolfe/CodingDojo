# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BlackBelt::Application.config.secret_token = 'eb3b378386f1c81a053092d00cdf1da32260fa38d2ab19bb001bba4363b51637e72c2227113d87910f67b31ff54cd45104bfa928469ef0750f79fe00fc4a69ad'
