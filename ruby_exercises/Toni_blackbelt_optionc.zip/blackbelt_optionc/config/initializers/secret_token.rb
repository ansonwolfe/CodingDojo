# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BlackbeltOptionc::Application.config.secret_token = 'e18baec2d2a6f9146dd4edcfadec3c80aa650b3577eaeabdc31531b8a75d6f5c089fe77e2e7def62f41ddec04c147ae6672fbc92fd2d2823d3ce433433261dd5'
