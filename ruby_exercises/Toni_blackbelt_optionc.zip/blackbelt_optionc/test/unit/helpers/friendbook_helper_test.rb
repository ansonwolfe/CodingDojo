require 'test_helper'

class FriendbookHelperTest < ActionView::TestCase
end
