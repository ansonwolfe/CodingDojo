class Basic2Migrate < ActiveRecord::Migration
  def up
  end

  def down
  end
end
