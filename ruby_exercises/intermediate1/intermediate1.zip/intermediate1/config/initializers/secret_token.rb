# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Intermediate1::Application.config.secret_token = 'f39df66a780b3d6985871a375e1a7ee03c19d5cbfa745f37492f322b66c1d9b5abd3836d2ef5f03a92184d17cb34640c8ecfef0c1821e0ca0f33333be00c9d9a'
