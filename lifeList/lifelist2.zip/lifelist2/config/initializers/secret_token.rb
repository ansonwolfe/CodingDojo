# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Lifelist2::Application.config.secret_token = 'c5c0e9c4624f5ec5ce5672674997acbb76c6358d717285e57cc0242e8258e4b3167e7c28a76a7af09d2461280ccca95070cc106725535bc724b4ef6ebe618b5c'
