class List < ActiveRecord::Base
  attr_accessible :description, :location, :name
end
